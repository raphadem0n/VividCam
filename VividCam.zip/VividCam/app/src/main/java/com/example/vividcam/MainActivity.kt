package com.example.vividcam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var shutter: Button
    private lateinit var seek: SeekBar
    private lateinit var status: TextView

    private var imageCapture: ImageCapture? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var intensity = 0.6f

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else {
                Toast.makeText(this, "Без доступа к камере приложение не работает", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        shutter = findViewById(R.id.shutter)
        seek = findViewById(R.id.seek)
        status = findViewById(R.id.status)

        // TextureView-режим, чтобы цветовой фильтр работал и на живом превью
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE

        seek.progress = (intensity * 100).toInt()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                intensity = progress / 100f
                status.text = "Интенсивность: $progress%"
                applyPreviewFilter()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        applyPreviewFilter()

        shutter.setOnClickListener { takePhoto() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun applyPreviewFilter() {
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(VividFilter.colorMatrix(intensity))
        }
        previewView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val level = intensity
        shutter.isEnabled = false
        status.text = "Обработка…"

        capture.takePicture(worker, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rotation = image.imageInfo.rotationDegrees
                    val raw = image.use { it.toBitmap() }
                    val rotated = rotate(raw, rotation)
                    val result = VividFilter.apply(rotated, level)
                    rotated.recycle()
                    save(result)
                    result.recycle()
                    runOnUiThread { status.text = "Сохранено: Галерея → Pictures/VividCam" }
                } catch (e: Throwable) {
                    runOnUiThread { status.text = "Ошибка: ${e.message}" }
                } finally {
                    runOnUiThread { shutter.isEnabled = true }
                }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread {
                    status.text = "Ошибка съёмки: ${e.message}"
                    shutter.isEnabled = true
                }
            }
        })
    }

    private fun rotate(bmp: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bmp
        val m = Matrix().apply { postRotate(degrees.toFloat()) }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (out != bmp) bmp.recycle()
        return out
    }

    private fun save(bmp: Bitmap) {
        val name = "VIVID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VividCam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Не удалось создать файл")
        contentResolver.openOutputStream(uri)?.use {
            bmp.compress(Bitmap.CompressFormat.JPEG, 95, it)
        } ?: throw IOException("Не удалось записать файл")
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }
}
