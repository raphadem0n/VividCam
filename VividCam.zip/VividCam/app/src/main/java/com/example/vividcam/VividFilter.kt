package com.example.vividcam

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

/**
 * Фильтр «насыщенно и детально»:
 * 1) повышение насыщенности и контраста (ColorMatrix),
 * 2) повышение резкости (unsharp-ядро 3x3).
 * k — интенсивность от 0 до 1.
 */
object VividFilter {

    fun colorMatrix(k: Float): ColorMatrix {
        val saturation = 1f + 0.8f * k     // до +80% насыщенности
        val contrast = 1f + 0.25f * k      // до +25% контраста
        val t = (0.5f - 0.5f * contrast) * 255f
        val result = ColorMatrix().apply { setSaturation(saturation) }
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, t,
                0f, contrast, 0f, 0f, t,
                0f, 0f, contrast, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
        result.postConcat(contrastMatrix)
        return result
    }

    fun apply(src: Bitmap, k: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix(k))
        }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        sharpen(out, 0.9f * k)
        return out
    }

    private fun sharpen(bmp: Bitmap, amount: Float) {
        if (amount < 0.01f) return
        val w = bmp.width
        val h = bmp.height
        val src = IntArray(w * h)
        bmp.getPixels(src, 0, w, 0, 0, w, h)
        val dst = src.copyOf()
        val center = 1f + 4f * amount

        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val p = src[i]
                val u = src[i - w]
                val d = src[i + w]
                val l = src[i - 1]
                val r = src[i + 1]

                val rr = center * ((p shr 16) and 0xFF) - amount *
                        (((u shr 16) and 0xFF) + ((d shr 16) and 0xFF) + ((l shr 16) and 0xFF) + ((r shr 16) and 0xFF))
                val gg = center * ((p shr 8) and 0xFF) - amount *
                        (((u shr 8) and 0xFF) + ((d shr 8) and 0xFF) + ((l shr 8) and 0xFF) + ((r shr 8) and 0xFF))
                val bb = center * (p and 0xFF) - amount *
                        ((u and 0xFF) + (d and 0xFF) + (l and 0xFF) + (r and 0xFF))

                dst[i] = (0xFF shl 24) or (clamp(rr) shl 16) or (clamp(gg) shl 8) or clamp(bb)
            }
        }
        bmp.setPixels(dst, 0, w, 0, 0, w, h)
    }

    private fun clamp(v: Float): Int = when {
        v < 0f -> 0
        v > 255f -> 255
        else -> v.toInt()
    }
}
