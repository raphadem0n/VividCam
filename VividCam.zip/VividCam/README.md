# VividCam

Камера для Android 10+ с фильтром «насыщенно и детально»:
живое превью с фильтром, ползунок интенсивности, сохранение в Pictures/VividCam.

## Сборка APK без компьютера (через GitHub)
1. Создайте новый репозиторий на github.com и загрузите туда все файлы проекта
   (Add file → Upload files; папку .github тоже).
2. Вкладка Actions → «Build APK» запустится сама (или Run workflow).
3. Через 3–5 минут откройте завершённый запуск → Artifacts → VividCam-apk.
4. Распакуйте zip, установите app-debug.apk (разрешите установку из неизвестных источников).

## Сборка в Android Studio
File → Open → папка VividCam → Build → Build APK(s).
